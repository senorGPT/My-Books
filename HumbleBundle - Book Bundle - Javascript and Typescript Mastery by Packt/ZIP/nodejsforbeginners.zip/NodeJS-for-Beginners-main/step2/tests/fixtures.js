const whispers = [{ id: 1, message: 'test' }, { id: 2, message: 'hello world' }]
const inventedId = 12345
const existingId = whispers[0].id

export {
  whispers,
  inventedId,
  existingId
}
