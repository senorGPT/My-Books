export default {
  modulePathIgnorePatterns: ['<rootDir>/node_test/']
}
