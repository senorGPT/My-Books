export default {
  modulePathIgnorePatterns: ['<rootDir>/node_test/'],
  coveragePathIgnorePatterns: [
    '<rootDir>/tests/'
  ]
}
