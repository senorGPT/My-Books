import "./App.css"
import Greeting from "./components/Greetings"

function App() {
  return (
    <>
      <div>
        <Greeting name="Theo" />
      </div>
      <h4>Vite + React + TypeScript</h4>
    </>
  )
}

export default App
