export const mul = (a: number, b: number) => a * b
