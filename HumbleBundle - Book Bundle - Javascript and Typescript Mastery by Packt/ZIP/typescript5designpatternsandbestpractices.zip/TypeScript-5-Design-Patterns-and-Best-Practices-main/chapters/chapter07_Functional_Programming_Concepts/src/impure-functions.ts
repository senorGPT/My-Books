function add(a: number, b: number): number {
  return a + b
}

console.log(add(2, 3)) // Always outputs 5
console.log(add(2, 3)) // Always outputs 5

