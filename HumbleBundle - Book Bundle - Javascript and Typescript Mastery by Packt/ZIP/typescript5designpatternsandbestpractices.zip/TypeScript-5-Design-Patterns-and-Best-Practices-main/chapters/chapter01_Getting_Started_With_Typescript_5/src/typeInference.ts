const numbers = []
numbers.push(1)
numbers.push("two")
