const degToRad = (degree: any): number => (degree * Math.PI) / 180
