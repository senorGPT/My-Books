function mul(a: number, b: number): number {
  return a * b
}

export default mul
