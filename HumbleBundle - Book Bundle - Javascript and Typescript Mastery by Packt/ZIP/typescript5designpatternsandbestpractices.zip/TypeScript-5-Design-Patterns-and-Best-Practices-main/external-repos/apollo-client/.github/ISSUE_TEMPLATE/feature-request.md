---
name: 🚀 Feature Request
about: Feature requests are managed in the Apollo Feature Request repo (https://github.com/apollographql/apollo-feature-requests).
---

Thanks for your interest in helping make Apollo Client better!

Feature requests and non-bug related discussions are no longer managed in this repo. Feature requests should be opened in https://github.com/apollographql/apollo-feature-requests.
