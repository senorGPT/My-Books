import { baseConfig } from "shared/playwright.config";
import { defineConfig } from "@playwright/test";

export default defineConfig(baseConfig);
