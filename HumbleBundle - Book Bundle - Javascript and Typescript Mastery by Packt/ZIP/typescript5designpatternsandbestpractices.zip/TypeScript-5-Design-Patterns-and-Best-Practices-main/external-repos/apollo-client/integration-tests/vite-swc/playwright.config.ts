import { baseConfig } from "shared/playwright.config.ts";
import { defineConfig } from "@playwright/test";

export default defineConfig(baseConfig);
