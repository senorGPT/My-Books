import './App.css';
import { PersonScore } from './PersonScore';

function App() {
  return <PersonScore />;
}

export default App;
