export default function Post() {
  return <main>Blog post one</main>;
}
