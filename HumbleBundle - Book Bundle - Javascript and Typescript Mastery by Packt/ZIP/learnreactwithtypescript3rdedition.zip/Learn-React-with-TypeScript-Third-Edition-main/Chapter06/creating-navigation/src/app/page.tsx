export default function Home() {
  return (
    <main>
      <h2>
        Welcome to my blog!
      </h2>
    </main>
  );
}
