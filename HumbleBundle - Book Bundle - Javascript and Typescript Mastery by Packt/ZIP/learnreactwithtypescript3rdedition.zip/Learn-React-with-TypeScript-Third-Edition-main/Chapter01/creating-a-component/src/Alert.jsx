export function Alert() {
  return (
    <div>
      <div>
        <span role="img" aria-label="Warning">
          ⚠️
        </span>
        <span>Oh no!</span>
      </div>
      <div>Something went wrong</div>
    </div>
  );
}
