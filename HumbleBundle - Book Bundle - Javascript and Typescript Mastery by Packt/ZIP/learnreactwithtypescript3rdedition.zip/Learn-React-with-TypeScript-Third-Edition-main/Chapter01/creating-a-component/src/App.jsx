import { Alert } from './Alert';

function App() {
  return <Alert />;
}

export default App;
