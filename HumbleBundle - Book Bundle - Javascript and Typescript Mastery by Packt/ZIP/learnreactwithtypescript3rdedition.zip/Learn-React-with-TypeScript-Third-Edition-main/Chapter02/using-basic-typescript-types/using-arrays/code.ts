const numbers: number[] = [];
// const numbers: Array<number> = [];
numbers.push(1);
numbers.push("two");

const numbers2 = [1, 2, 3];
