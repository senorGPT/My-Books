type RGB = "red" | "green" | "blue";
let color: RGB = "red";
color = "yellow";
