// let table = {name: "Table"; unitPrice: 450};
// table.discount = 10;

const table: { name: string; unitPrice?: number } = {
  name: "Table",
};
