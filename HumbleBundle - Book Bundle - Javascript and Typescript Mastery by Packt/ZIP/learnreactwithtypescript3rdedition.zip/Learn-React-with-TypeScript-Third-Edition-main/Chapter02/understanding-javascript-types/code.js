let firstName = "Fred";
console.log("firstName", firstName, typeof firstName);
let score = 9;
console.log("score", score, typeof score);
let date = new Date(2022, 10, 1);
console.log("date", date, typeof date);

score = "ten";
console.log("score", score, typeof score);
