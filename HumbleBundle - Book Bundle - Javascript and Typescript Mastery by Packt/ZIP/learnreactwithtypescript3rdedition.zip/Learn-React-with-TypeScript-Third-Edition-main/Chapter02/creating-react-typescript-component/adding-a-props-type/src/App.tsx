import { Alert } from './Alert';
import './App.css';

function App() {
  return <Alert heading="Success">Everything is really good!</Alert>;
}

export default App;
