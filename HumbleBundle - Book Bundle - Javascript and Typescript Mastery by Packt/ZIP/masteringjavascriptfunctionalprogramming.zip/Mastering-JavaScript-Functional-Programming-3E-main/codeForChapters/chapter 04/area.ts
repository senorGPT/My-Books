const PI = 3.14159265358979;

const circleArea = (r: number) => PI * r ** 2;

export { circleArea };
