const max = (...arr: number[]): number => Math.max(...arr);

const min = (...arr: number[]): number => Math.min(...arr);

export { min, max };
