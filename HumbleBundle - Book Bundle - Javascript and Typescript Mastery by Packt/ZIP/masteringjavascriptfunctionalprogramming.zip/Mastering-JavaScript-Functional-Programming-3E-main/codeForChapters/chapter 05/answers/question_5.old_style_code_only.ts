import { gettysburg } from "../flat";

const words = gettysburg.join(" ").split(" ").length;

console.log(words); // again 270
