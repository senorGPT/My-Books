const simpleAjax = (function () {
  const hard = require("hardajaxlibrary");

  const convertParamsToHardStyle = (params) => {
    // ...
  };

  const makeStandardUrl = (url) => {
    // ...
  };

  const getUrl = (url, params, callback) => {
    // ...
  };

  const postUrl = (url, params, callback) => {
    // ...
  };

  return { getUrl, postUrl };
})();
