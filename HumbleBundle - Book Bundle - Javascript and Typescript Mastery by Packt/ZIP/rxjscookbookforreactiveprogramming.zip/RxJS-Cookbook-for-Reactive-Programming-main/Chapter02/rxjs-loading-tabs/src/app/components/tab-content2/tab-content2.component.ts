import { Component } from '@angular/core';

@Component({
    selector: 'app-tab-content2',
    imports: [],
    templateUrl: './tab-content2.component.html',
    styleUrl: './tab-content2.component.scss'
})
export class TabContent2Component {

}
