export interface PixelCoordinates {
    x: number;
    y: number;
}