export const environment = {
    production: false,
    // Add your variable here
    configuration: 'development',
};