# Chat frontend

This repo is the Svelte frontend

## Start

1) `npm install`
2) `npm run dev`