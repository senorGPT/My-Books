import { createORMApp } from "./controllers/main";

const app = createORMApp();

export default app;
