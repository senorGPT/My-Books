import { createInMemoryApp } from "./controllers/main";

const app = createInMemoryApp();

export default app;
