export const API_PREFIX = "/api/v1";

export type ContextVariables = { Variables: { userId: string } };
