<script lang="ts">
    import Greeting from './Greeting.svelte';
</script>

<main>
    <Greeting name="John" />
</main>