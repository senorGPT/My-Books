<script lang="ts">
    export let name: string = 'World';
</script>

<main>
    <h1>Hello {name}!</h1>
</main>

<style>
    main {
        text-align: center;
        color: purple;
    }
</style>