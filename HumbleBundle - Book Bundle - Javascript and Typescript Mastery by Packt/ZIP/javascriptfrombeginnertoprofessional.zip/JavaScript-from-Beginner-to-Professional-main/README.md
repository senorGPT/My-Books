


# JavaScript-from-Beginner-to-Professional-
JavaScript from Beginner to Professional, Published by Packt



----------------------------------------------------
Each chapter contains the example codes explained in the book in the `Code Samples` directory along with `Exercises` and `Projects` from the book arranged chapterwise.
## Download a free PDF

 <i>If you have already purchased a print or Kindle version of this book, you can get a DRM-free PDF version at no cost.<br>Simply click on the link to claim your free PDF.</i>
<p align="center"> <a href="https://packt.link/free-ebook/9781800562523">https://packt.link/free-ebook/9781800562523 </a> </p>

## Errata
On page 43, in the console output at the end, the current output text `The distance of 130 kms is equal to 209.2142 miles` should be `The distance of 130 miles is equal to 209.2142 kms`.
