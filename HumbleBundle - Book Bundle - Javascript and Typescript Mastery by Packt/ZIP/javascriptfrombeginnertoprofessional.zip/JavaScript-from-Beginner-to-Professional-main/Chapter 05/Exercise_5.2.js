let counter = 0;
let step = 5;
do {
    console.log(counter);
    counter += step;
}
while (counter <= 100); 
