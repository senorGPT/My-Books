const val1 = 10;
const val2 = 5;
let operat = "-";
function cal(a, b, op) {
  if (op == "-") {
    console.log(a — b);
  } else {
    console.log(a + b);
  }
}
cal(val1, val2, operat);
