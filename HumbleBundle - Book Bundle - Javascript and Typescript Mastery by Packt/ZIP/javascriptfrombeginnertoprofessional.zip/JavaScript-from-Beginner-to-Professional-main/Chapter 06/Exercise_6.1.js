function adder(a, b) {
    return a + b;
}
const val1 = 10; 
const val2 = 20;
console.log(adder(val1, val2));
console.log(adder(20, 30));
