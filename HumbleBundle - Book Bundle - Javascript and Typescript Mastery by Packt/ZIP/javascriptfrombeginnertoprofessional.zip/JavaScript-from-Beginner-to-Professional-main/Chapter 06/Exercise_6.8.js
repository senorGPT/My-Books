const test = function(val){
    console.log(val);
}
test('hello 1');
 
function test1(val){
    console.log(val);
}
test1("hello 2");
