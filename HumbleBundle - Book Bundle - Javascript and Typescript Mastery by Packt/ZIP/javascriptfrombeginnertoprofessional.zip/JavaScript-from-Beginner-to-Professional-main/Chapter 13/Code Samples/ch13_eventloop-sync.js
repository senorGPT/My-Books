console.log("Hi there");
add(4,5);

function add(x, y) {
    return x + y;
}