console.log("Hi there");
setTimeout(() => console.log("Sorry I'm late"), 1000);
console.log(add(4,5));

function add(x, y) {
    return x + y;
}