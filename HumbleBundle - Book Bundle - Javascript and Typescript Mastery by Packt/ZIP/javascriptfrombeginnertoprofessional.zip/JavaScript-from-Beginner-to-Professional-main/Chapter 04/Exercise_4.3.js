const id = true;
const message = (id) ? "Allowed In" : "Denied Entry";
console.log(message);
