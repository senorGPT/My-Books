let varContainingFunction = function () {
  let varInFunction = "I'm in a function.";
  console.log("hi there!");
};

varContainingFunction();
