let x = 7;
console.log(Number.isNaN(x));
console.log(isNaN(x));
