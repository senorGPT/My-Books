console.log(window.location.protocol);
console.log(window.location.href);
