//alert("Saying hi from a different file!");
prompt("Hi! How are you?");