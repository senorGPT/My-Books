alert("Saying hi from a different file!");
