4 + 10
14

console.log("Laurence");
Laurence
undefined
