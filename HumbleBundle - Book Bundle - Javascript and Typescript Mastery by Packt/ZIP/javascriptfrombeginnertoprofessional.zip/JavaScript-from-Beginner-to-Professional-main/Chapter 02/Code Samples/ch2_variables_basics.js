let firstname = "Maria";
firstname = "Jacky";

let nr1 = 12;
var nr2 = 8;
const pi = 3.14159;

// throws a TypeError
const someConstant = 3;
someConstant = 4;
