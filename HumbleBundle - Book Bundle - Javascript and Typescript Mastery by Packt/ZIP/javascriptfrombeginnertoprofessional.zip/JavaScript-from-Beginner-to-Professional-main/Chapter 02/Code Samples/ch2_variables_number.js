let intNr = 1;
let decNr = 1.5;
let expNr = 1.4e15;

let bigNr = 90071992547409920n;
// typeError
let result = bigNr + intNr;
