let unassigned;
console.log(unassigned);

let terribleThingToDo = undefined;
let lastname;
console.log("Same undefined:", lastname === terribleThingToDo);

let betterOption = null;
console.log("Same null:", lastname === betterOption);

let empty = null;
