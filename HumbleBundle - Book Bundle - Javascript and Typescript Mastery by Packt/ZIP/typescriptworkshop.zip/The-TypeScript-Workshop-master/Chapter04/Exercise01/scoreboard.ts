class Team{
    generateLineup(){
        return "Lineup will go here...";
    }
}

const astros = new Team();
console.log(astros.generateLineup());