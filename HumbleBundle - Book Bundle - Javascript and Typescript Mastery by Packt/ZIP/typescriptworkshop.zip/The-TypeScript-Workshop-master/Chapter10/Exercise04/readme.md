#### Exercise 10.04 - Counting to five with promises

1. Install dependencies with `npm i`.

2. Compile the program with `tsc counting-2.ts`.

3. Verify that the compilation ended successfully and execute the result with `node counting-2.ts`
