setTimeout(function() {
    console.log("#1 Printed immediately?");
}, 0);

console.log("#2 Printed immediately.");