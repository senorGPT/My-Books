### Exercise 10.02 - Exploring `setTimeout`

1. Install dependencies with `npm i`.

2. Compile the program with `tsc delays-11.ts`.

3. Verify that the compilation ended successfully and execute the result with `delays-11.ts`

2. Compile the second program with `tsc delays-2.ts`.

3. Verify that the compilation ended successfully and execute the result with `delays-2.ts`
