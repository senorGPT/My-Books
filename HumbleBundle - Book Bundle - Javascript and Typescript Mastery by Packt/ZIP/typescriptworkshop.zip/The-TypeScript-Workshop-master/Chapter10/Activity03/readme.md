## Activity 10.03 - Movie browser using `fetch` and async / await

1. Install dependencies with `npm i`.

2. Compile the program with `tsc ./script.ts ./interfaces.ts ./display.ts`.

3. Verify that the compilation ended successfully.

4. Open the `index.html` using the browser of your choice.
