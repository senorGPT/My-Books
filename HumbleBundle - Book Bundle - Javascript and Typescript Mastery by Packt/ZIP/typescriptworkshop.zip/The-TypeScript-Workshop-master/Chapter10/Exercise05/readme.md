#### Exercise 10.05 - Counting to five with async and await

1. Install dependencies with `npm i`.

2. Compile the program with `tsc counting-3.ts`.

3. Verify that the compilation ended successfully and execute the result with `node counting-3.ts`
