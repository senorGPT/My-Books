#### Exercise 10.03 - Counting to five

1. Install dependencies with `npm i`.

2. Compile the program with `tsc counting-1.ts`.

3. Verify that the compilation ended successfully and execute the result with `node counting-1.ts`
