import {
  checkAvailability,
  getDestinations,
  holdSeats,
  reserveSeats,
} from './flights';

describe('flights tests', () => {
  const destinations = getDestinations();
  let flight = destinations[0];
  test('get destinations', () => {
    fail('Unimplemented!');
  });
  test('checking availability', () => {
    fail('Unimplemented!');
  });
  test('hold seats', () => {
    fail('Unimplemented!');
  });
  test('reserve seats', () => {
    fail('Unimplemented!');
  });
});
