# The TypeScript Workshop - Activity 3.01

1. Install dependencies with `npm i`.
2. Edit `bookings.test.ts` and `flights.test.ts` and implement the tests.
3. Execute the program with `npm t`.
4. The solutions can be run with `npm run test:solution`.
