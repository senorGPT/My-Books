import { completeBooking, processPayment, startBooking } from './bookings';
import { getDestinations } from './flights';

const destinations = getDestinations();

describe('bookings tests', () => {
  test('create a booking', () => {
    fail('Unimplemented!');
  });
  test('pay for a booking', () => {
    fail('Unimplemented!');
  });
  test('complete a booking', () => {
    fail('Unimplemented!');
  });
});

describe('error scenarios', () => {
  fail('Unimplemented!');
});
