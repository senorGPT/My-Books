# The TypeScript Workshop - Exercise 3.03

1. Install dependencies with `npm i`.
2. Edit `arrow-cat.ts` and implement the logic.
3. Execute the program with `npx ts-node arrow-cat.ts`.
