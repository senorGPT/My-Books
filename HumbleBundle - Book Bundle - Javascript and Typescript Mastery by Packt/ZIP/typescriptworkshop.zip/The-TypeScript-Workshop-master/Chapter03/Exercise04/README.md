# The TypeScript Workshop - Exercise 3.04

1. Install dependencies with `npm i`.
2. Edit `account.ts` and implement the logic.
3. Execute the program with `npx ts-node account.ts`.
