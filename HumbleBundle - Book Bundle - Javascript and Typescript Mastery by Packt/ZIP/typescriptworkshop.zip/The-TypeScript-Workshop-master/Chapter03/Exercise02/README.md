# The TypeScript Workshop - Exercise 3.02

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node array-equal.ts`.
