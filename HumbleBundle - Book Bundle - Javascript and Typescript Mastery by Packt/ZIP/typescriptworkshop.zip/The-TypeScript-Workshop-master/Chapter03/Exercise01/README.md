# The TypeScript Workshop - Exercise 3.01

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node Exercise01.ts`.
