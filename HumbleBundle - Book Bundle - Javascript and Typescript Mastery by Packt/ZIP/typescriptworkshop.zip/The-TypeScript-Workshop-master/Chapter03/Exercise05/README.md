# The TypeScript Workshop - Exercise 3.05

1. Install dependencies with `npm i`.
2. Edit `order.ts` and implement the logic.
3. Execute the program with `npx ts-node order.ts`.
