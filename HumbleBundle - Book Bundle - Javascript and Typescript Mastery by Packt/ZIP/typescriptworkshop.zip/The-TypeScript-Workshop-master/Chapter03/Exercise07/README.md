# The TypeScript Workshop - Exercise 3.07

1. Install dependencies with `npm i`.
2. Run `node refactor-shapes.js` to run the legacy code.
3. Edit `refactor-shapes.ts` and implement the logic.
4. Execute the program with `npx ts-node refactor-shapes.ts`.
