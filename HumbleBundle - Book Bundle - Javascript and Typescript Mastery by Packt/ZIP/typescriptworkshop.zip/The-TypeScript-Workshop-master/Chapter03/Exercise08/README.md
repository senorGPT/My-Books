# The TypeScript Workshop - Exercise 3.08

1. Install dependencies with `npm i`.
2. Implement a function library in `shapes-lib.ts`.
3. Import the library into `shapes.ts`.
4. Execute the program with `npx ts-node shapes.ts`.
