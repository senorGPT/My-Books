function myFunction(name: string): string {
    return `Hello ${name}!`;
  }
  const message = myFunction('world');
  console.log(message);
  // Hello world!
 // console.log(myFunction('world'));    