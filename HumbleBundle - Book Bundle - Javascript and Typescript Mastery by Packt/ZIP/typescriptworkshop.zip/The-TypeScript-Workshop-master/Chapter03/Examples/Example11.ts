(function () {
    console.log('Immediately invoked!');
 })();
 