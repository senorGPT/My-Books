const numbers = [1, 3, 2];

const filtered = numbers.filter(function(val) {return val < 3});

console.log(filtered);
