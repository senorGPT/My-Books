function myFunction(name?: string): string {
    return `Hello ${name}!`;
  }
  const message = myFunction();
  console.log(message);
    