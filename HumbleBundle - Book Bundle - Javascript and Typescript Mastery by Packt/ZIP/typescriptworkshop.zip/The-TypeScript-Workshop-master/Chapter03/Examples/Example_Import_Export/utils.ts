const PI = 3.14;

const addTwoNumbers = (a: number, b: number): number => a + b;

export { PI, addTwoNumbers };
// module syntax:
// module.exports = { PI, addTwoNumbers };
