import { PI, addTwoNumbers } from './utils';
// require syntax:
// const { PI, addTwoNumbers } = require('./utils');

console.log(PI);
console.log(addTwoNumbers(3, 4));
