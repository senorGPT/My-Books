let importantNumber = 3;

const addFive = (): void => {
    importantNumber += 5;
};

addFive();

console.log(importantNumber);
