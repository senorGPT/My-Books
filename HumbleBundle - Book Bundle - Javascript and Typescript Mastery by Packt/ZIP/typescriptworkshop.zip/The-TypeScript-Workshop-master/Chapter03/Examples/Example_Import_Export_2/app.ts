// app.ts
import utils from './utils';

console.log(utils.addTwo(3, 4));
