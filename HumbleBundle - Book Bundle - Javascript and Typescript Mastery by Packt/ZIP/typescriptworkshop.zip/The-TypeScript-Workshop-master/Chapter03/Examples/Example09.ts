const myFunction = function(name: string): string {
    return `Hello ${name}!`;
};
console.log(myFunction('function expression'));