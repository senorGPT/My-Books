# The TypeScript Workshop - Activity 3.01

1. Install dependencies with `npm i`.
2. Edit `bookings.ts` and `flights.ts` and implement the logic.
3. Execute the program with `npx ts-node index.ts`.
