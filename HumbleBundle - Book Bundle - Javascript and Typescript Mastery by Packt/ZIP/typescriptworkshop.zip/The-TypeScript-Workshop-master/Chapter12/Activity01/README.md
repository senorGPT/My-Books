# The TypeScript Workshop - Activity 12.01

1. Install dependencies with `npm i`.
2. Edit `app.ts` and implement the logic.
3. Transpile in watch mode with `npx tsc -w`.
4. Start the backend server from Exercise 12.06.
5. Start the web server with `http-server . -c-1`.
