# The TypeScript Workshop - Exercise 12.03

1. Install dependencies with `npm i`.
2. Edit `allSettled.ts` and implement the logic.
3. Execute the program with `npx ts-node allSettled.ts`.
