# The TypeScript Workshop - Exercise 12.05

1. Install dependencies with `npm i`.
2. Edit `file-concat.ts` and implement the logic.
3. Execute the program with `npx ts-node file-concat.ts`.
