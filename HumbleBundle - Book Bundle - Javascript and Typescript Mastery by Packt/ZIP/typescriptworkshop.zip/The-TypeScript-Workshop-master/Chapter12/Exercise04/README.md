# The TypeScript Workshop - Exercise 12.04

1. Install dependencies with `npm i`.
2. Enter `npx tsc -w data-loader.ts` to build in watch mode.
3. Enter `npx http-server . -c-1` in another terminal window to start the server.
4. Edit `data-loader.ts` and implement the logic.
