# The TypeScript Workshop - Exercise 12.02

1. Install dependencies with `npm i`.
2. Edit `recursive.ts` and implement the logic.
3. Execute the program with `npx ts-node recursive.ts`.
