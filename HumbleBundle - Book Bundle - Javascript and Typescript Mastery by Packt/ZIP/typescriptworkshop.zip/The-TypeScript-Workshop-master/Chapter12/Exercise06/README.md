# The TypeScript Workshop - Exercise 12.06

1. Install dependencies with `npm i`.
2. Edit `app.ts`, `db.ts`, and `router.ts` and implement the logic.
3. Start the app with `npx ts-node app.ts`.
