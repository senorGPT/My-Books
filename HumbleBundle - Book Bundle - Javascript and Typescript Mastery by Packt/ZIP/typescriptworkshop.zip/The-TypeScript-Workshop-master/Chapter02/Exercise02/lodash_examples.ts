import _ = require("lodash");
//const nums = [1, 2, 3];
//console.log(_.last(nums));
const number = 10;
console.log(_.last(number));

