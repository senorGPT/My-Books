// create a string and number literal  
type No = "no"
type Zero = 0
// function that takes type no
function onlyNo(no: No): Zero {
    return 0;
}
console.log(onlyNo("no"))