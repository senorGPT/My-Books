export function pipe() {}
