function greet(name: string) {
    console.log(`Hello ${name}`);
  }
  
  greet('John'); 
  