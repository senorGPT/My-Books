export const TYPES = {
  Logger: Symbol.for("Logger")
};
