import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	template: `
		<users-list></users-list>
	`,
})
export class AppComponent {}
