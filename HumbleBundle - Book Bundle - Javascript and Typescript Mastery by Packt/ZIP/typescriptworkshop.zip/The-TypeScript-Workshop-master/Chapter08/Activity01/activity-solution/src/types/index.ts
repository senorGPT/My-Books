export const TYPES = {
  Operator: Symbol.for("Operator"),
  Logger: Symbol.for("Logger"),
  ConfigService: Symbol.for("ConfigService")
};
