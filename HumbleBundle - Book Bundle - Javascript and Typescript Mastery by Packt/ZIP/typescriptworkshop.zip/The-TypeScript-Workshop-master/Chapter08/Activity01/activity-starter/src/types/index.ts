export const TYPES = {
    Operator: Symbol.for('Operator'),
};
