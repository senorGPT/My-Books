### Exercise 7.06 - Adding metadata to methods

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node calculator-metadata.ts`.

