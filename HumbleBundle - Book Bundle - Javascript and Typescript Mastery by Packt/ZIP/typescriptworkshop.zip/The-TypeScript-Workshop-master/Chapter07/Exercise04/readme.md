### Exercise 7.04 - Creating a decorator that marks a function enumerable

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node teacher-enumerating.start.ts`.