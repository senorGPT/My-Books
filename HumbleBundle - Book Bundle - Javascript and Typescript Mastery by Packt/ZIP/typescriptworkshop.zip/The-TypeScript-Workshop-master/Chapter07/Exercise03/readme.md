### Exercise 7.03 - Creating a logging decorator for a class

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node teacher-logging.ts`.