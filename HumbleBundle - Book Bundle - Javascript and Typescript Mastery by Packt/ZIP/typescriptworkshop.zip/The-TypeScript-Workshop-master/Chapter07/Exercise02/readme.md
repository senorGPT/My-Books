### Exercise 7.02 - Using a constructor extension decorator

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node school-token.start.ts`.