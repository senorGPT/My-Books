### Exercise 7.01 - Creating a simple class decorator factory

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node school-token.start.ts`.