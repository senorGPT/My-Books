### Exercise 7.08 - Creating and using a parameter decorator

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node teacher-parameters.ts`.

