### Exercise 7.07 - Creating and using a property decorator

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node teacher-properties.ts`.

