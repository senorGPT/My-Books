## Activity 7.02 - Using decorators to apply cross-cutting concerns

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node basket-ball-game.ts`.