## Activity 7.01 - Creating decorators for call counting

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node call-counting.ts`.