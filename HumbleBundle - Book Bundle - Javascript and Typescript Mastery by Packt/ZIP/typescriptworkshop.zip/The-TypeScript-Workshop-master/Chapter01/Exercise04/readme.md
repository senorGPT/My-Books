### Exercise 1.04 - Examining `typeof`

1. Install dependencies with `npm i`.

2. Compile the program with `tsc type-test.ts`.

3. Verify that the compilation ended successfully and execute the result with `node type-test.js`
