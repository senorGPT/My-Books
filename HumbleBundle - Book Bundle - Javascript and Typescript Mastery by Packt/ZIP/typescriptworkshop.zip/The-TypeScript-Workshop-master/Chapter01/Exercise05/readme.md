### Exercise 1.05 - Using Arrays and Tuples to create an efficient sort of objects

1. Install dependencies with `npm i`.

2. Compile the program with `tsc person-sort.ts`.

3. Verify that the compilation ended successfully and execute the result with `node person-sort.js`
