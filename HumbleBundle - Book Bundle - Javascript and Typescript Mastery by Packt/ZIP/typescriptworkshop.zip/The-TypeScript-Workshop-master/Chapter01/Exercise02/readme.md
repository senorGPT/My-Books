### Exercise 1.02 - Playing with functions

1. Install dependencies with `npm i`.

2. Compile the program with `tsc snippet.ts`.

3. Verify that the file did not compile correctly. 

4. Comment out or delete all invocations except the first one

5. Compile the program again with `tsc snippet.ts`.

6. Verify that the compilation ended successfully and execute the result with `node snippet.js`