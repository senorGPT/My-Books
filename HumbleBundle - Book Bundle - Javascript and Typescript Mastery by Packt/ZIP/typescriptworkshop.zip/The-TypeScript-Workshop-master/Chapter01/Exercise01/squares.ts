function squares(array: number[]) {
    const result = array.map(x => x * x);
    return result;
}