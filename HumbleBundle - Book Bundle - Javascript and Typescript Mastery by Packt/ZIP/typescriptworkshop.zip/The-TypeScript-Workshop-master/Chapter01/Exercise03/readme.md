### Exercise 1.03 - Working with objects

1. Install dependencies with `npm i`.

2. Compile the program with `tsc book.ts`.

3. Verify that the compilation ended successfully and execute the result with `node book.js`