### Exercise 1.06 - Making a calculator function;

1. Install dependencies with `npm i`.

2. Compile the program with `tsc calculator.start.ts`.

3. Verify that the compilation ended successfully and execute the result with `node calculator.start.js`
