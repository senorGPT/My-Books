# The TypeScript Workshop - Exercise 13.05

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node await-promise.ts`.
3. Modify the program per instructions and run again to see the variations.
