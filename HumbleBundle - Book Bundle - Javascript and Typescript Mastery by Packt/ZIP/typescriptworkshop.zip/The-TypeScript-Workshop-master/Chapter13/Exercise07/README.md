# The TypeScript Workshop - Activity 13.02

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node express.ts`.
3. Open the site in your browser at `http://localhost:8888`.
4. Implement additional logic as described in the text.
5. Experiment sending query params.
6. View the `names.txt` file to see your log.
