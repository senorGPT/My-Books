# The TypeScript Workshop - Exercise 13.01

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node target.ts`.
3. Change the `target` attribute in `tsconfig.json` and run `npx tsc` to see what the different transpiled outputs look like.
4. Try running a transpiled js file with `node target.js`.
