export const fn = async () => {
  return 'A Promise';
};

const result = fn();

console.log(result);
