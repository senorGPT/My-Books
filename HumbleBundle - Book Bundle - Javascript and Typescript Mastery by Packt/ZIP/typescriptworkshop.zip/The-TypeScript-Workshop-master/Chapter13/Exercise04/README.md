# The TypeScript Workshop - Exercise 13.04

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node await.ts`.
3. Modify the program per instructions and run again to see the variations.
