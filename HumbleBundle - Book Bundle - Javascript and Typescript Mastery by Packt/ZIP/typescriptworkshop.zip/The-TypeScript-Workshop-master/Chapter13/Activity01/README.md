# The TypeScript Workshop - Activity 13.01

1. Install dependencies with `npm i`.
2. Execute the program with `npx ts-node refactor.ts`.
3. Reimplement the logic using async/await.
