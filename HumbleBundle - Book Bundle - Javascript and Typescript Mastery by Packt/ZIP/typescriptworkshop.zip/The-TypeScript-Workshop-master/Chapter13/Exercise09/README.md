# The TypeScript Workshop - Activity 13.04

1. Install the NestJS cli with `npm i -g @nestjs/cli`.
2. Create a new application with `nest new typeorm-nest`
3. Follow the instructions and experiment with your new application.
