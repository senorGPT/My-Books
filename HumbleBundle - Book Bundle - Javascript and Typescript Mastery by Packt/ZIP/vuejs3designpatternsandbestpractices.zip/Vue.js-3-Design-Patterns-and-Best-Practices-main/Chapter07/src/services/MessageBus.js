import mitt from "mitt"

const MessageBus = new mitt()

export default MessageBus