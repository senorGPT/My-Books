<script setup>

</script>

<template>
    <header class="w3-blue w3-padding">
        <i class="fa-solid fa-fw fa-list"></i>
        To-Do List
    </header>
</template>

<style scoped>

</style>