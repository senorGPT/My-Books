<script setup>
    
</script>

<template>
    <h1>Chapter 5: Nested routes example</h1>
    <p>This example shows how to define and view nested routes with default views.</p>
    <RouterLink :to="{name:'directory'}">Open the directory</RouterLink>
</template>

<style scoped>
    
</style>