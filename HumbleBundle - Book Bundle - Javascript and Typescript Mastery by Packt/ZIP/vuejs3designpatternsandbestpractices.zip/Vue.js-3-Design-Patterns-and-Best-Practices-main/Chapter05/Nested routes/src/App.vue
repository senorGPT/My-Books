<script setup>
import { RouterLink, RouterView } from "vue-router"
</script>

<template>
<div>
  <RouterView />
</div>
</template>

<style scoped>
div{
    height: 100vh;
    font-family: sans-serif;
}

</style>
