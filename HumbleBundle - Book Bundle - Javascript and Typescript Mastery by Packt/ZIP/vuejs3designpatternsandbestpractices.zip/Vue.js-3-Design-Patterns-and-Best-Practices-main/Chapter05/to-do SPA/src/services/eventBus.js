import mitt from "mitt"

const eventBus = new mitt()

export default eventBus