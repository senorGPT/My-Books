 # To-Do List Single Page Application - Chapter 5

## Created by Pablo D. Garaguso (2022)

This application builds on the concepts seen from chapters 1 to 5. 

To install dependencies run:

`npm install`

To run the application in developer mode, run:

`npm run serve`

Follow the instructions on the terminal to open the website in your browser.