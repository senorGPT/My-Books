import my_method1_singleton from "./singleton-json";
import my_method2_singleton from "./singleton-class";

console.log("Look mom, no instantiation!")

my_method1_singleton.myFunction()
my_method2_singleton.myFunction()

