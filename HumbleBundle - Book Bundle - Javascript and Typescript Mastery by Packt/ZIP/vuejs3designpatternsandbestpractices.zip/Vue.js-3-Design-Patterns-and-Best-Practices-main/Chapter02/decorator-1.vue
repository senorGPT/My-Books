<script setup>
    const $props=defineProps(["label"])
</script>

<template>
    <h1>{{$props.label}}</h1>
</template>

<style scoped></style>