const my_singleton={
    myFunction(){
        console.log("Singleton alive and well")
    }
}

export default my_singleton;