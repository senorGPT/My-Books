Chapters 1, 2, and 5 does not contain any code snippets.

Chapter 1 explains us the basics of various differential robots.

Chapter 2 deals with the modeling of differential robots.

Chapter 5 exaplins how to interface sensors and various actuators of the robots.