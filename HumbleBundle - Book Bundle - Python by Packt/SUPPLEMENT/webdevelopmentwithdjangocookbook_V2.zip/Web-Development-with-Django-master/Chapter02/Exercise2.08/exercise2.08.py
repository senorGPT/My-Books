#!/usr/bin/env python3

from reviews.models import Contributor

contributors = Contributor.objects.all()
