Python Microservices Development, by Packt

Chapter 11 does not have any code files. All other chapters have code files arranged in the folder of respective chapter.
The source code for the Runnerly application that is developed across the book is also provided in the code bundle.