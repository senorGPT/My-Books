APIS
====


**TokenDealer** has three views:

.. autofunction:: tokendealer.views.home._jwks

.. autofunction:: tokendealer.views.home.create_token

.. autofunction:: tokendealer.views.home.verify_token
