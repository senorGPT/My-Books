from .home import home


blueprints = [home]
