The code bundle consists of code from all the chapters except for Chapter 1.

The code bundle does not have code for Chapter 1 as the commands from Chapter 1 can be directly executed by copy pasting it to the command prompt.