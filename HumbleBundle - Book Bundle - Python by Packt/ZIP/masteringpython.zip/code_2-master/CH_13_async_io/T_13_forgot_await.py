async def printer():
    print('This is a coroutine')


printer()
