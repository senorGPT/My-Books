import os
def test(a,b):
    return c
