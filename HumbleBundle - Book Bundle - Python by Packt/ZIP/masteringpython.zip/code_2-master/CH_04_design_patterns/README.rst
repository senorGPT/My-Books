Chapter 3, Containers and Collections
------------------------------------------------------------------------------

| Storing Data the Right Way using the many containers and collections bundled with Python to create code that is fast and readable.
