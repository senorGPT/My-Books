>>> 'Hello world!'
'Hello world!'
