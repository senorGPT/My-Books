>>> sandwich = dict(spam=2, eggs=1, sausage=1)
>>> sandwich.<TAB>  # doctest: +SKIP
sandwich.clear(       sandwich.fromkeys(    sandwich.items(       sandwich.pop(
sandwich.setdefault(  sandwich.values(      sandwich.copy(        sandwich.get(
sandwich.keys(        sandwich.popitem(     sandwich.update(
>>> sandwich[  # doctest: +SKIP


>>> sandwich = dict(spam=2, eggs=1, sausage=1)
>>> sandwich['<TAB>  # doctest: +SKIP
sandwich['eggs']     sandwich['sausage']  sandwich['spam']

>>> import T_02_modifying_autocompletion

>>> autocompletion = T_02_modifying_autocompletion
