Spam: :class:`spam.Spam`

------------------------------------------------------------------------------

Link to the intersphinx module: :mod:`sphinx.ext.intersphinx`
