.. image:: python.png
   :width: 150
   :height: 100

.. image:: python.png
   :scale: 10

------------------------------------------------------------------------------

.. figure:: python.png
   :scale: 10

   The Python logo
