The switch to reStructuredText and Sphinx was made with the
`Python 2.6 <https://docs.python.org/whatsnew/2.6.html>`_
release.

------------------------------------------------------------------------------

The switch to reStructuredText and Sphinx was made with the 
`python 2.6`_ release.

.. _`Python 2.6`: https://docs.python.org/whatsnew/2.6.html

------------------------------------------------------------------------------

The introduction section
================================================================

This section contains:

- `chapter 1`_
- :ref:`chapter2`

  1. my_label_

  2. `And a label link with a custom title <my_label>`_

Chapter 1
----------------------------------------------------------------

Jumping back to the beginning of `chapter 1`_ is also possible.
Or jumping to :ref:`Chapter 2 <chapter2>`

.. _chapter2:

Chapter 2 With a longer title
----------------------------------------------------------------
 
The next chapter.

.. _my_label:

The label points here.

Back to `the introduction section`_
