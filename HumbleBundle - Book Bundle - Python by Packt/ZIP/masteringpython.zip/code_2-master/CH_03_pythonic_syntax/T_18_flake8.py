def spam(a,b,c):print(a,b+c)
def eggs():pass
