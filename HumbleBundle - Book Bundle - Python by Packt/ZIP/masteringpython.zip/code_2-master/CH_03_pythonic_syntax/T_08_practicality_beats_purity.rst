>>> from concurrent.futures import ProcessPoolExecutor, \
...     CancelledError, TimeoutError

>>> from concurrent.futures import (
...     ProcessPoolExecutor, CancelledError, TimeoutError)

>>> from concurrent import futures

>>> from concurrent.futures.process import (
...     ProcessPoolExecutor
... )

>>> from concurrent.futures import (
...     ProcessPoolExecutor,
...     CancelledError,
...     TimeoutError,
... )

