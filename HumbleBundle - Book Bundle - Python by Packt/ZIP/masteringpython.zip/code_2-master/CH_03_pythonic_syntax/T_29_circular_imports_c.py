import T_29_circular_imports_b


class FileC(T_29_circular_imports_b.FileB):
    pass
