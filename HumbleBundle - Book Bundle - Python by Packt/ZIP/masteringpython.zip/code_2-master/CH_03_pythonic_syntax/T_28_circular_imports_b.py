import T_28_circular_imports_a


class FileB(T_28_circular_imports_a.FileA):
    pass
