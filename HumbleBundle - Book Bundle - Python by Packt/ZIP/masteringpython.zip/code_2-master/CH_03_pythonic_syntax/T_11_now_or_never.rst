>>> import warnings

>>> warnings.warn('Something deprecated', DeprecationWarning)
