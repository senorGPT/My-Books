class FileA:
    pass
