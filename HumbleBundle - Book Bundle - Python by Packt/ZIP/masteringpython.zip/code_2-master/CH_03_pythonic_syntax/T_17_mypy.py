some_number: int
some_number = 'test'
