>>> from json import loads

>>> loads('{}')
{}

>>> import json

>>> json.loads('{}')
{}
