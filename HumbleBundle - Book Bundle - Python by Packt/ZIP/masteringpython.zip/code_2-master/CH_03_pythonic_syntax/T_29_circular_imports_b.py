import T_29_circular_imports_a


class FileB(T_29_circular_imports_a.FileA):
    pass
