Code samples for Mastering Python Second Edition
##############################################################################

Mastering Python Second Edition, published by Packt

Code samples from Mastering Python Second Edition
(https://www.packtpub.com/application-development/mastering-python-second-edition)

All of the code in this repository is tested using the bundled tests. To run
the tests yourself simply install the requirements and run the tests:

    pip3 install --upgrade --requirement requirements.txt
    py.test

**NOTE** Python 3.10.0b4 or higher is required to run the tests.

------------------------------------------------------------------------------

If you are interested in more packages from the author, take a look at his
Github account: https://github.com/WoLpH/
