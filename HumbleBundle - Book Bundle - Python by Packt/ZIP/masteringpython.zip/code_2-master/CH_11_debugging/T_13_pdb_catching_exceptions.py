print('This still works')
1 / 0
print('We will never reach this')
