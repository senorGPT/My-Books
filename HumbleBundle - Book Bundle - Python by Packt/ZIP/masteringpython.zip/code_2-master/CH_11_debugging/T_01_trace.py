def some_test_function(a, b):
    c = a + b
    return c


print(some_test_function('a', 'b'))
