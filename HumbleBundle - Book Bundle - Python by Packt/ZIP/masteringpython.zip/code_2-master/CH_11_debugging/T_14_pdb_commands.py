def do_nothing(i):
    pass


for i in range(10):
    do_nothing(i)
