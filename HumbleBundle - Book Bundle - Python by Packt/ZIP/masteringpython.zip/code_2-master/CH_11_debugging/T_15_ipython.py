def print_value(value):
    print('value:', value)


if __name__ == '__main__':
    for i in range(5):
        print_value(i)
