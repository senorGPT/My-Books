Chapter 12, Performance
##############################################################################

| Tracking and Reducing your Memory and CPU Usage shows several methods of measuring and improving CPU and memory usage.
