import timeit

timeit.main(args=['[x for x in range(1000000)]'])
