host = 'localhost'
port = 12345
password = b'some secret password'

