from . import base


class A(base.Plugin):
    pass

