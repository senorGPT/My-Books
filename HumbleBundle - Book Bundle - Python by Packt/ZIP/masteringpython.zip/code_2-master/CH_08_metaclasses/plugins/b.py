from . import base


class B(base.Plugin):
    pass

